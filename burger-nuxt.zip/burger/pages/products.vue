<template>
  <div id="product">
    <header-pam title="Produits">

      <p>mon text prodcut</p>
    </header-pam>
    <info-text>
      <p></p>
    </info-text>
  </div>
</template>


<style >
</style>
