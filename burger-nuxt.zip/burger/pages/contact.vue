<template>
  <div id="contact">
    <header-pam title="contact">

      <p>Contact</p>
    </header-pam>
  </div>
</template>


<style >
</style>
