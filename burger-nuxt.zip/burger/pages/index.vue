<template>
  <div>

    <header-pam
      title="pamplemouss"
      image="true"
    >

      <p>Le Fast-Food Pamplemouss’ est situé au centre ville d’Annecy sur une place ensoleillée au bord de Thiou, à l’écart de l’agitation et du bruit.</p>
      <a
        href="#"
        class="btn-gradient"
      >COMMANDER</a>

    </header-pam>

    <info-text>
      <p>Au quotidien nous vous proposons <strong>l’assiette Bio.</strong> <br> Nous proposons également des plats végétariens et sans gluten.
      </p>
      <p>
        Selon vos envies et votre temps, déjeunez ou dinez sur place, en terrasse, à emporter ou en livraison ! </p>
      <p>Des ruptures de produits peuvent survenir car nous cuisinons des produits frais et de saisons. Nous vous remercions de votre compréhension.</p>

    </info-text>
  </div>
</template>


<style lang="scss">
</style>
