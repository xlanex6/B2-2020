<template>
  <div id="history">
    <header-pam title="Histoire">

      <p>Unique enseigne de restauration rapide certifiée 100% Bio. En créant Pamplemouss’, Louis et Anthony se sont donné pour mission de démocratiser l’Agriculture Biologique grâce à un plat aimé de tous, le hamburger.</p>

    </header-pam>
    <info-text>
      <p></p>
    </info-text>
  </div>
</template>


<style >
</style>
