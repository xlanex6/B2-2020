<template>
  <div id="about">

    <header-pam title="about">

      <p>Nous travaillons à créer un écosystème viable et durable pour tous les acteurs : les consommateurs, les producteurs, les employés, les partenaires. Au fil des années, nous avons construit une vraie expertise en matière de sourcing bio et ainsi noué des liens rapprochés avec nos fournisseurs dont plusieurs d’entre eux nous sont fidèles depuis la création de Pamplemouss’.</p>
    </header-pam>

    <info-text>
      <p>NOS STEAKS HACHES Ils nous viennent d’une coopérative d’éleveurs bio de Rumilly. Ils nous fournissent des steaks hachés frais, façon bouchère, 100% pur bœuf pesant 110g chacun. Chaque steak est cuit « minute », à point. NOTRE FROMAGE Il nous vient de la ferme Arc en ciel tenue à Reignier par un couple de haut-savoyards qui a décidé dans les années 90, d’exporter leur savoir-faire dans une ferme entièrement biologique. Ils livrent des tommes qui sont tranchées chaque jour en restaurant. NOS PAINS Notre boulanger est installé à Groisy. La recette du pain Pamplemouss’, légèrement brioché, a été spécialement élaborée pour l’enseigne. Tous les jours, les pains sont découpés en restaurant avant d’être toastés « minute » pour chaque commande. NOS PATATES Nos pommes de terre proviennent d’une coopérative de 130 producteurs bio dans la région Haute- Savoie. De variété Agria, elles sont lavées, découpées chaque matin en restaurant puis cuites à la commande. NOS BOISSONS Toutes les boissons ont été créées exclusivement pour Pamplemouss’ par notre fournisseur localisé à Annecy. Elles sont composées d’extraits de fruits bio, de plantes bio, de sucre de canne bio, d’eau filtrée plate ou gazeuse et c’est tout !</p>
    </info-text>
  </div>
</template>


<style >
</style>
