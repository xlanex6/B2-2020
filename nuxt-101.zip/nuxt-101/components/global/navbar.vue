<template>
  <nav>
    <nuxt-link to="/">home</nuxt-link>
    <nuxt-link to="/blog">blog</nuxt-link>
  </nav>
</template>

<style lang="scss">
nav {
  width: 100%;
  margin: auto;
  height: $navBarHeight;
  padding: 0 40px;
  display: flex;
  align-items: center;
  box-shadow: 0px 0px 15px #00000031;
  a {
    font-size: 20px;
    color: inherit;
    text-decoration: none;
    flex: 0 1 100px;
    height: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    &:hover {
      background-color: lightgray;
    }
  }
  .nuxt-link-exact-active {
    background-color: lightgray;
    color: white;
  }
}
</style>


