
export default {
  ssr: false,
  target: 'static',
  head: {
    title: 'NUXT is LIFE',
    meta: [
      { charset: 'utf-8' },
      { name: 'viewport', content: 'width=device-width, initial-scale=1' },
      { hid: 'description', name: 'description', content: process.env.npm_package_description || '' }
    ],
    link: [
      { rel: 'icon', type: 'image/x-icon', href: '/favicon.ico' }
    ]
  },
  css: ['~/assets/scss/main.scss','~/assets/scss/button.scss','~/assets/scss/colors.scss','~/assets/scss/utility.scss'
  ],
  plugins: [
  ],
  components: true,
  buildModules: [
  ],
  modules: [
    '@nuxtjs/style-resources'
  ],
  styleResources: {
    scss: ['~/assets/scss/*.scss']
  },
  build: {
  }
}
