<template>
  <div class="container">
    <h1 class="title">BLOG PAGE</h1>
  </div>
</template>


<style >
</style>
