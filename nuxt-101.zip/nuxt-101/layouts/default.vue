<template>
  <div>
    <navbar />
    <Nuxt />
    <myfooter />
  </div>
</template>

<style>



</style>
